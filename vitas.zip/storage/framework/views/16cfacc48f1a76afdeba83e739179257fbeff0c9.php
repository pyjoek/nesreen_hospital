<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo e(config('app.name')); ?></title>
</head>
<body>
    <div class="container">
        <table>
            <thead>
                <tr>
                    <td>STOCK ITEM</td>
                    <td>QUANTITY</td>
                    <td>PRICE</td>
                    <td>DELIVERY NUMBER</td>
                    <td>DATE RECIEVED</td>
                    <td>DATE SOLD</td>
                </tr>
            </thead>
            <tbody>
            <?php $__currentLoopData = $datas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($data->stock_item); ?></td>
                <td><?php echo e($data->quantity); ?></td>
                <td><?php echo e($data->price); ?></td>
                <td><?php echo e($data->delivery_no); ?></td>
                <td><?php echo e($data->date_recieved); ?></td>
                <td><?php echo e($data->date_sold); ?></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
    <div class="container">
      <!-- Content for the right side goes here -->
      <h2>Stock Information</h2>
      <button class="btn btn-primary"><a href="/vita1/new">Add New Stock</a></button>
      <h2>Vita Store Branch 1</h2>

      <table id="stock-table">
        <thead>
          <tr>
            <th>STOCK ITEM</th>
            <th>QUANTITY</th>
            <th>PRICE</th>
            <th>DELIVERY NUMBER</th>
            <th>DATE RECIEVED</th>
            <th>DATE SOLD</th>
          </tr>
        </thead>
        <tbody>
          <?php $__currentLoopData = $datas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($data->stock_item); ?></td>
                <td><?php echo e($data->quantity); ?></td>
                <td><?php echo e($data->price); ?></td>
                <td><?php echo e($data->delivery_no); ?></td>
                <td><?php echo e($data->date_recieved); ?></td>
                <td><?php echo e($data->date_sold); ?></td>
            </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
      </table>
    </div>
</body>
</html><?php /**PATH /home/dragon/Documents/Php/dar_systems/vitaStore/resources/views/vita1/vita1Store.blade.php ENDPATH**/ ?>